# Booki
***

## Dernières modifications
***
15/11/2022

## Informations générales
***
Page d'accueil réalisée pour le Projet 3 de la formation Intégrateur WEB dispensée par le site Open Classrooms.

Validation W3C
* HTML : 3 warnings
* CSS : validée
## Technologies
***
HTML et CSS

## Contenu
***
* Site de réservation de logement et d'activités.
* Orientation desktop first.
* La page est faite pour s'adapter sur tablette et mobile.
* Les liens présents ne sont pas clicables.